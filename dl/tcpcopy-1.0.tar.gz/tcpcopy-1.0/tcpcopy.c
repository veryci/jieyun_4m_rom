
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <linux/types.h>
#include <linux/netfilter.h>		/* for NF_ACCEPT */
#include<linux/tcp.h>
#include<linux/ip.h>

#include <libnetfilter_queue/libnetfilter_queue.h>

static int l_fd;
static unsigned char l_buffer[8192];

void createdatafile(char *filename)
{
	l_fd = open(filename, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR); /* 创建并打开文件 */
}

void writefile(int fd, char *pdata, int len)
{
	int head = 0xaa55;
	int tail = 0x55aa;

	memcpy(l_buffer, &head, 2);
	memcpy(l_buffer+2, &len, 2);
	memcpy(l_buffer+4, pdata, len);
	memcpy(l_buffer+len+4, &tail, 2);

	if(fd) 
	{
		write(fd, pdata, len+6);
	}
}

/* returns packet id */
static u_int32_t process_pkt (struct nfq_data *tb)
{
	int id = 0;
	struct nfqnl_msg_packet_hdr *ph;
	struct nfqnl_msg_packet_hw *hwph;
	u_int32_t mark,ifi; 
	int ret;
	unsigned char *data;

#if 0
	ph = nfq_get_msg_packet_hdr(tb);
	if (ph) {
		id = ntohl(ph->packet_id);
		printf("hw_protocol=0x%04x hook=%u id=%u ",
			ntohs(ph->hw_protocol), ph->hook, id);
	}

	hwph = nfq_get_packet_hw(tb);
	if (hwph) {
		int i, hlen = ntohs(hwph->hw_addrlen);

		printf("hw_src_addr=");
		for (i = 0; i < hlen-1; i++)
			printf("%02x:", hwph->hw_addr[i]);
		printf("%02x ", hwph->hw_addr[hlen-1]);
	}

	mark = nfq_get_nfmark(tb);
	if (mark)
		printf("mark=%u ", mark);

	ifi = nfq_get_indev(tb);
	if (ifi)
		printf("indev=%u ", ifi);

	ifi = nfq_get_outdev(tb);
	if (ifi)
		printf("outdev=%u ", ifi);
	ifi = nfq_get_physindev(tb);
	if (ifi)
		printf("physindev=%u ", ifi);

	ifi = nfq_get_physoutdev(tb);
	if (ifi)
		printf("physoutdev=%u ", ifi);

	ret = nfq_get_payload(tb, &data);
	if (ret >= 0)
		printf("payload_len=%d ", ret);

	fputc('\n', stdout);
#endif

    ph = nfq_get_msg_packet_hdr(tb);
    if (ph) {
        id = ntohl(ph->packet_id);
    }

    ret = nfq_get_payload(tb, &data);
    if (ret >= 0){
		struct iphdr* iph=(struct iphdr*)data;
		struct tcphdr* tcph=NULL;
		unsigned short srcport,dstport,iplen;
		unsigned char *http_data=NULL;

		unsigned int ipheadlen=0;
		unsigned int tcpheadlen=0;
		unsigned short off;

		__u8 srcaddr[4]={0};
		__u8 dstaddr[4]={0};
		__be32 src=iph->saddr;
		__be32 dst=iph->daddr;

		memcpy(&srcaddr,&src,4);
		memcpy(&dstaddr,&dst,4);
		ipheadlen=iph->ihl*4;
		tcph=(struct tcphdr*)((unsigned char*)iph+ipheadlen);
		tcpheadlen=tcph->doff*4;
		srcport=ntohs(tcph->source);
		dstport=ntohs(tcph->dest);
		iplen=ntohs(iph->tot_len);
		off=iph->frag_off;

		//writefile(l_fd, data, iplen);

		printf("write %d\r\n", iplen);
	}

	return id;
}
	

static int cb(struct nfq_q_handle *qh, struct nfgenmsg *nfmsg,
	      struct nfq_data *nfa, void *data)
{
	printf("recv \n");
	u_int32_t id = process_pkt(nfa);
	printf("entering callback\n");
	return nfq_set_verdict(qh, id, NF_ACCEPT, 0, NULL);
}

int main(int argc, char **argv)
{
	struct nfq_handle *h;
	struct nfq_q_handle *qh;
	struct nfnl_handle *nh;
	int fd;
	int rv;
	char buf[4096] __attribute__ ((aligned));

	
	createdatafile("/data.bin");

	printf("opening library handle\n");
	h = nfq_open();
	if (!h) {
		fprintf(stderr, "error during nfq_open()\n");
		exit(1);
	}

	printf("unbinding existing nf_queue handler for AF_INET (if any)\n");
	if (nfq_unbind_pf(h, AF_INET) < 0) {
		fprintf(stderr, "error during nfq_unbind_pf()\n");
		exit(1);
	}

	printf("binding nfnetlink_queue as nf_queue handler for AF_INET\n");
	if (nfq_bind_pf(h, AF_INET) < 0) {
		fprintf(stderr, "error during nfq_bind_pf()\n");
		exit(1);
	}

	printf("binding this socket to queue '0'\n");
	qh = nfq_create_queue(h,  0, &cb, NULL);
	if (!qh) {
		fprintf(stderr, "error during nfq_create_queue()\n");
		exit(1);
	}

	printf("setting copy_packet mode\n");
	if (nfq_set_mode(qh, NFQNL_COPY_PACKET, 0xffff) < 0) {
		fprintf(stderr, "can't set packet_copy mode\n");
		exit(1);
	}

	fd = nfq_fd(h);

	while (1) {
		rv = recv(fd, buf, sizeof(buf), 0);
		if(rv < 0)
		{
			printf("rv = %d !!!!!!!!!!\r\n", rv);
			continue;
		}
		//printf("pkt received\n");
		nfq_handle_packet(h, buf, rv);
	}

	printf("unbinding from queue 0\n");
	nfq_destroy_queue(qh);

#ifdef INSANE
	/* normally, applications SHOULD NOT issue this command, since
	 * it detaches other programs/sockets from AF_INET, too ! */
	printf("unbinding from AF_INET\n");
	nfq_unbind_pf(h, AF_INET);
#endif

	printf("closing library handle\n");
	nfq_close(h);

	exit(0);
}
