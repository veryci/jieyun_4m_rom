/*
* =====================================================================================
*
* Filename: nf_queue_test.c
*
* Description: 用netfilter_queue 在用户态修改网络数据包的例子程序
*
* Version: 1.0
* Created: 04/02/2010 09:49:48 AM
* Revision: none
* Compiler: gcc
*
* Author: LeiuX (xulei), xulei@pact518.hit.edu.cn
* Company: HIT
*
* =====================================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netdb.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <asm/byteorder.h>
#include <linux/netfilter.h>
#include <libnetfilter_queue/libnetfilter_queue.h>
#include <linux/ip.h>
#include <linux/tcp.h>

#ifdef __LITTLE_ENDIAN
#define IPQUAD(addr) \
	((unsigned char *)&addr)[0], \
	((unsigned char *)&addr)[1], \
	((unsigned char *)&addr)[2], \
	((unsigned char *)&addr)[3]
#else
#define IPQUAD(addr) \
	((unsigned char *)&addr)[3], \
	((unsigned char *)&addr)[2], \
	((unsigned char *)&addr)[1], \
	((unsigned char *)&addr)[0]
#endif

static int cb(struct nfq_q_handle *qh, struct nfgenmsg *nfmsg,
	struct nfq_data *nfa, void *data)
{
	(void)nfmsg;
	(void)data;
	u_int32_t id = 0;
	struct nfqnl_msg_packet_hdr *ph;
	unsigned char *pdata = NULL;
	int pdata_len;

	ph = nfq_get_msg_packet_hdr(nfa);
	if (ph){
		id = ntohl(ph->packet_id);
	}

	pdata_len = nfq_get_payload(nfa, (char**)&pdata);
	if(pdata_len == -1){
		pdata_len = 0;
	}

	struct iphdr *iphdrp = (struct iphdr *)pdata;

	printf("len %d iphdr %d %u.%u.%u.%u ->",
		pdata_len,
		iphdrp->ihl<<2,
		IPQUAD(iphdrp->saddr));
	printf(" %u.%u.%u.%u %s",
		IPQUAD(iphdrp->daddr),
		getprotobynumber(iphdrp->protocol)->p_name);

	printf("\n");

	return nfq_set_verdict_mark(qh, id, NF_REPEAT, 1,
		(u_int32_t)pdata_len, pdata);
}

int main(int argc, char **argv)
{
	struct nfq_handle *h;
	struct nfq_q_handle *qh;
	struct nfnl_handle *nh;
	int fd;
	int rv;
	char buf[4096];

	h = nfq_open();
	if (!h) {
		exit(1);
	}

	nfq_unbind_pf(h, AF_INET);

	/*2.6.24 的内核有BUG， nfq_unbind_pf 返回值不正确，
	见：http://article.gmane.org/gmane.c ... ilter.general/33573*/

	/*
	if (nfq_unbind_pf(h, AF_INET) < 0){
	exit(1);
	}
	*/

	if (nfq_bind_pf(h, AF_INET) < 0) {
		exit(1);
	}

	int qid = 0;
	if(argc == 2){
		qid = atoi(argv[1]);
	}
	printf("binding this socket to queue %d\n", qid);
	qh = nfq_create_queue(h, qid, &cb, NULL);
	if (!qh) {
		exit(1);
	}

	if (nfq_set_mode(qh, NFQNL_COPY_PACKET, 0xffff) < 0) {
		exit(1);
	}

	nh = nfq_nfnlh(h);
	fd = nfnl_fd(nh);

	while ((rv = recv(fd, buf, sizeof(buf), 0)) && rv >= 0) {
		nfq_handle_packet(h, buf, rv);
	}

	/* never reached */
	nfq_destroy_queue(qh);

	nfq_close(h);

	exit(0);
}
