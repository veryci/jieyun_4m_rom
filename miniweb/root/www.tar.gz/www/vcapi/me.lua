#!/bin/lua
string = "Lua Tutorial"
-- 查找字符串
ii, jj=string.find(string,"Tutorial")
print(ii, jj)
--reversedString = string.reverse(string)
--print("新字符串为",reversedString)
